package com.hometalk.onepass.community.dto.response;

import com.hometalk.onepass.auth.entity.User;
import com.hometalk.onepass.community.entity.Post;
import com.hometalk.onepass.community.enums.PostFileType;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostResponseDTO {
    private Long id;
    private Long authorId;      // 본인 확인 ID
    private String title;
    private String content;

    private String boardName;
    private Long categoryId;
    private String categoryName;
    private String categoryCode;

    private List<String> tags;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private int likeCount;
    private int dislikeCount;
    private boolean isLiked;
    private boolean isDisliked;

    private int viewCount;
    private int commentCount;

    private String writer;      // 닉네임
    private boolean editable;
    private boolean admin;
    private boolean pinned;
    private boolean isDeleted;

    private boolean hasImage;
    private String thumbnailPath;

    private String categoryBgColor;
    private String categoryTextColor;

    // 1. 시스템 관리 상태
    private String postStatus;                  // 로직용 - "ACTIVE", "HIDDEN" (CSS 클래스나 조건문용)
    private String postStatusDescription;       // 표시용 - "활성", "숨김" (사용자 화면 출력용)

    private boolean canModify;

    // 2. 나눔 게시글 상태
    private String marketStatus;                // 로직용: "SHARED", "SOLD"
    private String marketStatusDescription;     // 표시용: "나눔중", "완료"

    // 3. 거래 게시글 상태
    private String tradeType;                   // 로직용: "BUY", "SELL"
    private String tradeTypeDescription;        // 표시용: "구매", "판매"
    private String tradeStatus;                 // 로직용: "SELLING", "RESERVED", "COMPLETED"
    private String tradeStatusDescription;      // 표시용: "거래중", "예약중", "완료"

    // Entity -> DTO 변환 생성자
    public PostResponseDTO(Post post) {
        this.id = post.getId();
        this.title = post.getTitle();
        this.content = post.getContent();
        this.pinned = post.isPinned();

        this.hasImage = post.isHasImage();
        // 대표 썸네일 조회
        if (post.getFiles() != null && !post.getFiles().isEmpty()) {
            post.getFiles().stream()
                    .filter(file -> file.getFileType() == PostFileType.THUMBNAIL)
                    .findFirst()
                    .ifPresent(file -> this.thumbnailPath = file.getFilePath());
        }

        if (post.getCategory() != null) {
            this.categoryId = post.getCategory().getId();
            this.categoryName = post.getCategory().getName();
            this.categoryCode = post.getCategory().getCode();
            // 색상 필드 매핑
            this.categoryBgColor = post.getCategory().getBgColor();
            this.categoryTextColor = post.getCategory().getTextColor();

            // 종속 관계를 안전하게 연결
            if (post.getCategory().getBoard() != null) {
                this.boardName = post.getCategory().getBoard().getName();
            }
        }

        // 작성자 정보 처리
        if (post.getWriter() != null) {
            this.authorId = post.getWriter().getId();       // ID 담기
            this.writer = post.getWriter().getNickname();  // 닉네임 담기
        }

        if (post.getPostTags() != null && !post.getPostTags().isEmpty()) {
            this.tags = post.getPostTags().stream()
                    .map(pt -> pt.getTag().getName())
                    .collect(Collectors.toList());
        } else {
            this.tags = new ArrayList<>(); // null 대신 빈 리스트
        }

        this.createdAt = post.getCreatedAt();
        this.updatedAt = post.getUpdatedAt();
        this.isDeleted = (post.getDeletedAt() != null);

        this.likeCount = post.getLikeCount();
        this.dislikeCount = post.getDislikeCount();
        this.viewCount = post.getViewCount();
        this.commentCount = post.getCommentCount();

        // 게시글 상태
        this.postStatus = post.getPostStatus().name();
        this.postStatusDescription = post.getPostStatus().getDescription();

        // 나눔 게시글 상태
        if ("share".equalsIgnoreCase(post.getCategory().getCode())
                && post.getMarketStatus() != null
                && !post.isPinned()) {

            this.marketStatus = post.getMarketStatus().name();
            this.marketStatusDescription = post.getMarketStatus().getDescription();

        } else {
            this.marketStatus = null;
            this.marketStatusDescription = null;
        }

        // 거래 게시글 상태
        if ("trade".equalsIgnoreCase(post.getCategory().getCode())
                && post.getTradeType() != null
                && post.getTradeStatus() != null
                && !post.isPinned()) {

            this.tradeType = post.getTradeType().name();
            this.tradeTypeDescription = post.getTradeType().getDescription();

            this.tradeStatus = post.getTradeStatus().name();
            this.tradeStatusDescription = post.getTradeStatus().getDescription();

        } else {
            this.tradeType = null;
            this.tradeTypeDescription = null;
            this.tradeStatus = null;
            this.tradeStatusDescription = null;
        }

    }

    public static PostResponseDTO from(Post post) {
        PostResponseDTO dto = new PostResponseDTO(post);

        List<String> systemBoards = List.of("square", "market", "talk");
        String boardCode = (post.getCategory() != null && post.getCategory().getBoard() != null)
                ? post.getCategory().getBoard().getCode()
                : "";

        dto.setCanModify(!systemBoards.contains(boardCode));
        return dto;
    }

    public PostResponseDTO(Post post, boolean isLiked, boolean isDisliked) {
        this(post);
        this.isLiked = isLiked;
        this.isDisliked = isDisliked;
    }
}
